// Express initialization

var express = require('express');
var http= require("http");  
var app = express();
var bodyParser = require("body-parser")
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
	extended:true
}));

//used for geocoder - see README.md
//var geocoder = require('geocoder');

//Mongo initialization, setting up a connection to a MongoDB  (on Heroku or localhost)
var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/whereintheworld'; // comp20 is the name of the database we are using in MongoDB
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
  db = databaseConnection;
});

//endable CORS
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

app.get('/', function (request, response) {
  response.set('Content-Type', 'text/html');
	var HTMLstring ="";	
	location = db.collection('locations');
	location.find().sort({timestamp:-1}).limit(100).toArray(function(error,data){
		data.forEach(function(elem){

			//Ming said to leave this section. See README for disscusion
			/*geocoder.reverseGeocode(elem.lat, elem.lng, function(err, res){
				if (res != undefined){console.log(res["results"][0]["formatted_address"]);}
				HTMLstring +='<p>' + elem.login + ", " + res + ", " + elem.timestamp + '</p>';
			});*/

		HTMLstring +='<p>' + elem.login + ", " + elem.lat + ", "+ elem.lng+ ", " + elem.timestamp + '</p>';
		});
	response.send('<p>' + HTMLstring+'</p>');
	});	 
});

app.post('/sendLocation', function (request, response) {
location = db.collection('locations');
	response.set('Content-Type', 'application/json');
	if (request.body.login && request.body.lat && request.body.lng) {
  		var login = request.body.login;
  		var lat = request.body.lat;
   		var long = request.body.lng;
  		var characters = [];
  		d = new Date();
			location.insert(
				{
					login:login,
					lat:lat,
					lng:long,
					timestamp:d
				}, function (error, results){ 
						location.find().sort({timestamp:-1}).limit(100).toArray(function(error, data){
						response.send(
						 	{
								characters:characters,
								students:data
					  	});
						});
					 }
			);
	}
});

app.get('/locations.json', function (request, response) {
location = db.collection('locations');
response.set('Content-Type', 'application/json');
	if (request.query.login) {
  		var user = request.query.login;
			location.find({login:user}).sort({timestamp:-1}).limit(100).toArray(function(error, data){
				response.send(
		 			{
						students:data
			  	});
			});	
	}
else response.send({students:[]});
});

app.get('/redline.json', function (request, response) {
	var data = '';
	http.get("http://developer.mbta.com/lib/rthr/red.json", function(apiresponse) {
		apiresponse.on('data', function(chunk) {
			data += chunk;
		});
		apiresponse.on('end', function() {
			response.send(data);
		});
	}).on('error', function(error) {
		response.send(500);
	});
});

app.listen(process.env.PORT || 3000);
